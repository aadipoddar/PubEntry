CREATE PROCEDURE Load_AdvanceTotals_By_TakenOn
	@TakenOn DATE,
    @LocationId INT
AS
BEGIN

	SELECT
		PaymentMode,
		Amount
	FROM View_AdvanceTotals
	WHERE DateTime BETWEEN @TakenOn AND DATEADD(DAY, 1, @TakenOn)
		AND LocationId = @LocationId

END
go

